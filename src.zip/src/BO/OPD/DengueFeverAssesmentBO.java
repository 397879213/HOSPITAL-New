/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO.OPD;

/**
 *
 * @author admin
 */
public class DengueFeverAssesmentBO {
    
    private String CON = "";
    private String ODI = "";
    private String defTypeId = "";
    private String defTypeDescription = "";
    private String detailId = "";
    private String detailDescription = "";
    private String additionlaInfo = "";
    private String selection = "";
    private String remarks = "";

    public String getCON() {
        return CON;
    }

    public void setCON(String CON) {
        this.CON = CON;
    }

    public String getODI() {
        return ODI;
    }

    public void setODI(String ODI) {
        this.ODI = ODI;
    }

    public String getSelection() {
        return selection;
    }

    public void setSelection(String selection) {
        this.selection = selection;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getDefTypeId() {
        return defTypeId;
    }

    public void setDefTypeId(String defTypeId) {
        this.defTypeId = defTypeId;
    }

    public String getDefTypeDescription() {
        return defTypeDescription;
    }

    public void setDefTypeDescription(String defTypeDescription) {
        this.defTypeDescription = defTypeDescription;
    }

    public String getDetailId() {
        return detailId;
    }

    public void setDetailId(String detailId) {
        this.detailId = detailId;
    }

    public String getDetailDescription() {
        return detailDescription;
    }

    public void setDetailDescription(String detailDescription) {
        this.detailDescription = detailDescription;
    }

    public String getAdditionlaInfo() {
        return additionlaInfo;
    }

    public void setAdditionlaInfo(String additionlaInfo) {
        this.additionlaInfo = additionlaInfo;
    }
    
}
