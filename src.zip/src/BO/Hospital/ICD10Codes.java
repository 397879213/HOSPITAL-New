/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO.Hospital;

/**
 *
 * @author Usman
 */
public class ICD10Codes {

    private String chapterNo = "";
    private String chapterTittle = "";
    private String blockCode = "";
    private String blockTittle = "";
    private String codeDescription = "";
    private String hierarchyLevel = "";
    private String placement = "";
    private String whoEdition = "";
    private String terminalNodeType = "";
    private String withoutDagger = "";
    private String withoutAsterick = "";
    private String withoutDot = "";

    public String getChapterNo() {
        return chapterNo;
    }

    public void setChapterNo(String chapterNo) {
        this.chapterNo = chapterNo;
    }

    public String getChapterTittle() {
        return chapterTittle;
    }

    public void setChapterTittle(String chapterTittle) {
        this.chapterTittle = chapterTittle;
    }

    public String getBlockCode() {
        return blockCode;
    }

    public void setBlockCode(String blockCode) {
        this.blockCode = blockCode;
    }

    public String getBlockTittle() {
        return blockTittle;
    }

    public void setBlockTittle(String blockTittle) {
        this.blockTittle = blockTittle;
    }

    public String getCodeDescription() {
        return codeDescription;
    }

    public void setCodeDescription(String codeDescription) {
        this.codeDescription = codeDescription;
    }

    public String getHierarchyLevel() {
        return hierarchyLevel;
    }

    public void setHierarchyLevel(String hierarchyLevel) {
        this.hierarchyLevel = hierarchyLevel;
    }

    public String getPlacement() {
        return placement;
    }

    public void setPlacement(String placement) {
        this.placement = placement;
    }

    public String getWhoEdition() {
        return whoEdition;
    }

    public void setWhoEdition(String whoEdition) {
        this.whoEdition = whoEdition;
    }

    public String getTerminalNodeType() {
        return terminalNodeType;
    }

    public void setTerminalNodeType(String terminalNodeType) {
        this.terminalNodeType = terminalNodeType;
    }

    public String getWithoutDagger() {
        return withoutDagger;
    }

    public void setWithoutDagger(String withoutDagger) {
        this.withoutDagger = withoutDagger;
    }

    public String getWithoutAsterick() {
        return withoutAsterick;
    }

    public void setWithoutAsterick(String withoutAsterick) {
        this.withoutAsterick = withoutAsterick;
    }

    public String getWithoutDot() {
        return withoutDot;
    }

    public void setWithoutDot(String withoutDot) {
        this.withoutDot = withoutDot;
    }

}
