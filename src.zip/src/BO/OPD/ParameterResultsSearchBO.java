/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO.OPD;

/**
 *
 * @author raheelansari
 */
public class ParameterResultsSearchBO {

    private String patientId = "";
    private String patientName = "";
    private String age = "";
    private String genderId = "";
    private String genderDescription = "";
    private String clientId = "";
    private String clientDescription = "";
    private String cptId = "";
    private String cptDescription = "";
    private String parameterId = "";
    private String parameterDescription = "";
    private String resultValue = "";
    private String verifiedtDate = "";
    private String con = "";
    private String odi = "";
    
    private String fromDate = "";
    private String toDate = "";
    private String bgId = "";
    private String fromAge = "";
    private String toAge = "";
    private String fromResult = "";
    private String toResult = "";

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getBgId() {
        return bgId;
    }

    public void setBgId(String bgId) {
        this.bgId = bgId;
    }

    public String getFromAge() {
        return fromAge;
    }

    public void setFromAge(String fromAge) {
        this.fromAge = fromAge;
    }

    public String getToAge() {
        return toAge;
    }

    public void setToAge(String toAge) {
        this.toAge = toAge;
    }

    public String getFromResult() {
        return fromResult;
    }

    public void setFromResult(String fromResult) {
        this.fromResult = fromResult;
    }

    public String getToResult() {
        return toResult;
    }

    public void setToResult(String toResult) {
        this.toResult = toResult;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGenderId() {
        return genderId;
    }

    public void setGenderId(String genderId) {
        this.genderId = genderId;
    }

    public String getGenderDescription() {
        return genderDescription;
    }

    public void setGenderDescription(String genderDescription) {
        this.genderDescription = genderDescription;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientDescription() {
        return clientDescription;
    }

    public void setClientDescription(String clientDescription) {
        this.clientDescription = clientDescription;
    }

    public String getCptId() {
        return cptId;
    }

    public void setCptId(String cptId) {
        this.cptId = cptId;
    }

    public String getCptDescription() {
        return cptDescription;
    }

    public void setCptDescription(String cptDescription) {
        this.cptDescription = cptDescription;
    }

    public String getParameterId() {
        return parameterId;
    }

    public void setParameterId(String parameterId) {
        this.parameterId = parameterId;
    }

    public String getParameterDescription() {
        return parameterDescription;
    }

    public void setParameterDescription(String parameterDescription) {
        this.parameterDescription = parameterDescription;
    }

    public String getResultValue() {
        return resultValue;
    }

    public void setResultValue(String resultValue) {
        this.resultValue = resultValue;
    }

    public String getVerifiedtDate() {
        return verifiedtDate;
    }

    public void setVerifiedtDate(String verifiedtDate) {
        this.verifiedtDate = verifiedtDate;
    }

    public String getCon() {
        return con;
    }

    public void setCon(String con) {
        this.con = con;
    }

    public String getOdi() {
        return odi;
    }

    public void setOdi(String odi) {
        this.odi = odi;
    }
    
    
    
}
