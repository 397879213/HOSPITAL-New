package BO ;

public class TerWiseEmp {

    private String terminalId = "";
    private String fromTerminalId = "";
    private String toTerminalId = "";
    private String locationId = "";
    private String orderLocationId = "";
    private String deptId = "";
    private String locationName = "";
    private String orderLocationName = "";
    private String deptName = "";
    private String terDescription = "";
    private String active = "";
    private String terminalType = "";
    private String empId = "";
    private String empName = "";
    private String fullName = "";
    private String designationId = "";
    private String designationName = "";

    public String getTerminalId() {
        return terminalId;
    }

    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getTerDescription() {
        return terDescription;
    }

    public void setTerDescription(String terDescription) {
        this.terDescription = terDescription;
    }

   

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getTerminalType() {
        return terminalType;
    }

    public void setTerminalType(String terminalType) {
        this.terminalType = terminalType;
    }

    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getDesignationId() {
        return designationId;
    }

    public void setDesignationId(String designationId) {
        this.designationId = designationId;
    }

    public String getDesignationName() {
        return designationName;
    }

    public void setDesignationName(String designationName) {
        this.designationName = designationName;
    }

    public String getOrderLocationId() {
        return orderLocationId;
    }

    public void setOrderLocationId(String orderLocationId) {
        this.orderLocationId = orderLocationId;
    }

    public String getOrderLocationName() {
        return orderLocationName;
    }

    public void setOrderLocationName(String orderLocationName) {
        this.orderLocationName = orderLocationName;
    }

    public String getFromTerminalId() {
        return fromTerminalId;
    }

    public void setFromTerminalId(String fromTerminalId) {
        this.fromTerminalId = fromTerminalId;
    }

    public String getToTerminalId() {
        return toTerminalId;
    }

    public void setToTerminalId(String toTerminalId) {
        this.toTerminalId = toTerminalId;
    }
   
   
}
