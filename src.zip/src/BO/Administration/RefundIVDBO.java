/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BO.Administration;

/**
 *
 * @author raheelansari
 */
public class RefundIVDBO {
    
    private String con = "";
    private String odi = "";
    private String refundAmount = "";

    public String getCon() {
        return con;
    }

    public void setCon(String con) {
        this.con = con;
    }

    public String getOdi() {
        return odi;
    }

    public void setOdi(String odi) {
        this.odi = odi;
    }

    public String getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(String refundAmount) {
        this.refundAmount = refundAmount;
    }
    
    
}
