/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO.BloodBank;

/**
 *
 * @author admin
 */
public class ArmyPersonBO {
    
    private String armyPersonId = "";
    private String patientId = "";
    private String PANo = "";
    private String fullName = "";
    private String fromDate = "";
    private String toDate = "";
    private String dayOfBirth = "";
    private String age = "";
    private String dob = "";
    private String maritalStatusId = "";
    private String maritalStatusDesc = "";
    private String bloodGroupId = "";
    private String bloodGroupDesc = "";
    private String rankId = "";
    private String rankDesc = "";
    private String cityId = "";
    private String cityDesc = "";
    private String address = "";
    private String unit = "";
    private String crtdBy = "";
    private String crtdUserName = "";
    private String crtdDate = "";
    private String crtdTerminalId = "";

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getDayOfBirth() {
        return dayOfBirth;
    }

    public void setDayOfBirth(String dayOfBirth) {
        this.dayOfBirth = dayOfBirth;
    }

    public String getCrtdBy() {
        return crtdBy;
    }

    public void setCrtdBy(String crtdBy) {
        this.crtdBy = crtdBy;
    }

    public String getCrtdUserName() {
        return crtdUserName;
    }

    public void setCrtdUserName(String crtdUserName) {
        this.crtdUserName = crtdUserName;
    }

    public String getCrtdDate() {
        return crtdDate;
    }

    public void setCrtdDate(String crtdDate) {
        this.crtdDate = crtdDate;
    }

    public String getCrtdTerminalId() {
        return crtdTerminalId;
    }

    public void setCrtdTerminalId(String crtdTerminalId) {
        this.crtdTerminalId = crtdTerminalId;
    }

    public String getArmyPersonId() {
        return armyPersonId;
    }

    public void setArmyPersonId(String armyPersonId) {
        this.armyPersonId = armyPersonId;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public String getPANo() {
        return PANo;
    }

    public void setPANo(String PANo) {
        this.PANo = PANo;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getMaritalStatusId() {
        return maritalStatusId;
    }

    public void setMaritalStatusId(String maritalStatusId) {
        this.maritalStatusId = maritalStatusId;
    }

    public String getBloodGroupId() {
        return bloodGroupId;
    }

    public void setBloodGroupId(String bloodGroupId) {
        this.bloodGroupId = bloodGroupId;
    }

    public String getRankId() {
        return rankId;
    }

    public void setRankId(String rankId) {
        this.rankId = rankId;
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getMaritalStatusDesc() {
        return maritalStatusDesc;
    }

    public void setMaritalStatusDesc(String maritalStatusDesc) {
        this.maritalStatusDesc = maritalStatusDesc;
    }

    public String getBloodGroupDesc() {
        return bloodGroupDesc;
    }

    public void setBloodGroupDesc(String bloodGroupDesc) {
        this.bloodGroupDesc = bloodGroupDesc;
    }

    public String getRankDesc() {
        return rankDesc;
    }

    public void setRankDesc(String rankDesc) {
        this.rankDesc = rankDesc;
    }

    public String getCityDesc() {
        return cityDesc;
    }

    public void setCityDesc(String cityDesc) {
        this.cityDesc = cityDesc;
    }
    
    
}
