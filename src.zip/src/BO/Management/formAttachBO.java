/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BO.Management;

/**
 *
 * @author razas
 */
public class formAttachBO {
    
     private String id = "";
     private String title = "";
     private String menuName = "";
     private String formName = "";
     private String active = "";
     private String description = "";
     private String webURL = "";
     private String webEnabled = "";
     private String desktopEnabled = "";
     private String menuId = "";
     private String position = "";
     private String crtdBy = "";
     private String crtdDate = "";
     private String uptdBy = "";
     private String uptdDate = "";

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getCrtdBy() {
        return crtdBy;
    }

    public void setCrtdBy(String crtdBy) {
        this.crtdBy = crtdBy;
    }

    public String getCrtdDate() {
        return crtdDate;
    }

    public void setCrtdDate(String crtdDate) {
        this.crtdDate = crtdDate;
    }

    public String getUptdBy() {
        return uptdBy;
    }

    public void setUptdBy(String uptdBy) {
        this.uptdBy = uptdBy;
    }

    public String getUptdDate() {
        return uptdDate;
    }

    public void setUptdDate(String uptdDate) {
        this.uptdDate = uptdDate;
    }

    public String getMenuId() {
        return menuId;
    }

    public void setMenuId(String menuId) {
        this.menuId = menuId;
    }
     

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMenuName() {
        return menuName;
    }

    public void setMenuName(String menuName) {
        this.menuName = menuName;
    }

    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getWebURL() {
        return webURL;
    }

    public void setWebURL(String webURL) {
        this.webURL = webURL;
    }

    public String getWebEnabled() {
        return webEnabled;
    }

    public void setWebEnabled(String webEnabled) {
        this.webEnabled = webEnabled;
    }

    public String getDesktopEnabled() {
        return desktopEnabled;
    }

    public void setDesktopEnabled(String desktopEnabled) {
        this.desktopEnabled = desktopEnabled;
    }
    
}
