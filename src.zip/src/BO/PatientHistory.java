/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO;

/**
 *
 * @author Muhammad Rafia
 */
public class PatientHistory {
    
    private String patinetId;
    private String fullName;
    private String age;
    private String contactNo;
    private String updatedFullName;
    private String dob;
    private String updtContactNo;
    private String updAge;
    private String updateName;
    private String updtTerminal;
    private String client;
    private String location;
    private String updatedBy;
    private String updatedDate;
    private String updatedTerminalId;
    private String PatId;
    private String fName;
    private String patAge;
    private String contNo;
    private String uptdBy;
    private String crtDate;
    private String acces;
    private String accessId;
    private String remarks;

    public String getFsType() {
        return fsType;
    }

    public void setFsType(String fsType) {
        this.fsType = fsType;
    }
    private String fsType;

    public String getPatId() {
        return PatId;
    }

    public void setPatId(String PatId) {
        this.PatId = PatId;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getPatAge() {
        return patAge;
    }

    public void setPatAge(String patAge) {
        this.patAge = patAge;
    }

    public String getContNo() {
        return contNo;
    }

    public void setContNo(String contNo) {
        this.contNo = contNo;
    }

    public String getUptdBy() {
        return uptdBy;
    }

    public void setUptdBy(String uptdBy) {
        this.uptdBy = uptdBy;
    }

    public String getCrtDate() {
        return crtDate;
    }

    public void setCrtDate(String crtDate) {
        this.crtDate = crtDate;
    }

    public String getAcces() {
        return acces;
    }

    public void setAcces(String acces) {
        this.acces = acces;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
   
    
    
    
    

    public String getUpdtTerminal() {
        return updtTerminal;
    }

    public void setUpdtTerminal(String updtTerminal) {
        this.updtTerminal = updtTerminal;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedTerminalId() {
        return updatedTerminalId;
    }

    public void setUpdatedTerminalId(String updatedTerminalId) {
        this.updatedTerminalId = updatedTerminalId;
    }

 
    

    public String getPatinetId() {
        return patinetId;
    }

    public void setPatinetId(String patinetId) {
        this.patinetId = patinetId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getUpdatedFullName() {
        return updatedFullName;
    }

    public void setUpdatedFullName(String updatedFullName) {
        this.updatedFullName = updatedFullName;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getUpdtContactNo() {
        return updtContactNo;
    }

    public void setUpdtContactNo(String updtContactNo) {
        this.updtContactNo = updtContactNo;
    }

    public String getUpdAge() {
        return updAge;
    }

    public void setUpdAge(String updAge) {
        this.updAge = updAge;
    }

    public String getUpdateName() {
        return updateName;
    }

    public void setUpdateName(String updateName) {
        this.updateName = updateName;
    }

    public String getAccessId() {
        return accessId;
    }

    public void setAccessId(String accessId) {
        this.accessId = accessId;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }
}
