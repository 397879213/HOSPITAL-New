/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BO.Inventory;

/**
 *
 * @author raheelansari
 */
public class OutreachPathInventory {
    
    private String manualIndentId = "";
    private String itemId = "";
    private String itemDescription = "";
    private String storeId = "";
    private String storeDescription = "";
    private String quantity = "";
    private String userId = "";
    private String userName = "";
    private String moveStoreId = "";
    private String moveStoreDescription = "";
    private String crtdBy = "";
    private String crtdByName = "";
    private String crtdDate = "";
    private String crtdTerminalId = "";

    public String getManualIndentId() {
        return manualIndentId;
    }

    public void setManualIndentId(String manualIndentId) {
        this.manualIndentId = manualIndentId;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public String getStoreDescription() {
        return storeDescription;
    }

    public void setStoreDescription(String storeDescription) {
        this.storeDescription = storeDescription;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMoveStoreId() {
        return moveStoreId;
    }

    public void setMoveStoreId(String moveStoreId) {
        this.moveStoreId = moveStoreId;
    }

    public String getMoveStoreDescription() {
        return moveStoreDescription;
    }

    public void setMoveStoreDescription(String moveStoreDescription) {
        this.moveStoreDescription = moveStoreDescription;
    }

    public String getCrtdBy() {
        return crtdBy;
    }

    public void setCrtdBy(String crtdBy) {
        this.crtdBy = crtdBy;
    }

    public String getCrtdDate() {
        return crtdDate;
    }

    public void setCrtdDate(String crtdDate) {
        this.crtdDate = crtdDate;
    }

    public String getCrtdTerminalId() {
        return crtdTerminalId;
    }

    public void setCrtdTerminalId(String crtdTerminalId) {
        this.crtdTerminalId = crtdTerminalId;
    }

    public String getCrtdByName() {
        return crtdByName;
    }

    public void setCrtdByName(String crtdByName) {
        this.crtdByName = crtdByName;
    }
}
