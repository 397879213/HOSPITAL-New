/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BO.Administration;

/**
 *
 * @author raheelansari
 */
public class MonthlyLocationExpenseBO {
    
    private String expenseMasterId = "";
    private String expenseTypeId = "";
    private String expenseTypeDescription = "";
    private String locationId = "";
    private String locationDescription = "";
    private String expenseMonth = "";
    private String closeStatus = "";
    private String active = "";
    private String totalAmount = "";
    private String amount = "";
    private String fianlBy = "";
    private String fianlDate = "";
    private String fianlTerminalId = "";
    private String crtdBy = "";
    private String crtdDate = "";
    private String crtdTerminalId = "";
    private String defTypeId = "";
    private String defTypeDescription = "";
    private String detailId = "";
    private String detailDescription = "";

    public String getLocationDescription() {
        return locationDescription;
    }

    public void setLocationDescription(String locationDescription) {
        this.locationDescription = locationDescription;
    }

    public String getExpenseTypeDescription() {
        return expenseTypeDescription;
    }

    public void setExpenseTypeDescription(String expenseTypeDescription) {
        this.expenseTypeDescription = expenseTypeDescription;
    }
    
    public String getExpenseMasterId() {
        return expenseMasterId;
    }

    public void setExpenseMasterId(String expenseMasterId) {
        this.expenseMasterId = expenseMasterId;
    }

    public String getExpenseTypeId() {
        return expenseTypeId;
    }

    public void setExpenseTypeId(String expenseTypeId) {
        this.expenseTypeId = expenseTypeId;
    }

    public String getLocationId() {
        return locationId;
    }

    public void setLocationId(String locationId) {
        this.locationId = locationId;
    }

    public String getExpenseMonth() {
        return expenseMonth;
    }

    public void setExpenseMonth(String expenseMonth) {
        this.expenseMonth = expenseMonth;
    }

    public String getCloseStatus() {
        return closeStatus;
    }

    public void setCloseStatus(String closeStatus) {
        this.closeStatus = closeStatus;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getFianlBy() {
        return fianlBy;
    }

    public void setFianlBy(String fianlBy) {
        this.fianlBy = fianlBy;
    }

    public String getFianlDate() {
        return fianlDate;
    }

    public void setFianlDate(String fianlDate) {
        this.fianlDate = fianlDate;
    }

    public String getFianlTerminalId() {
        return fianlTerminalId;
    }

    public void setFianlTerminalId(String fianlTerminalId) {
        this.fianlTerminalId = fianlTerminalId;
    }

    public String getCrtdBy() {
        return crtdBy;
    }

    public void setCrtdBy(String crtdBy) {
        this.crtdBy = crtdBy;
    }

    public String getCrtdDate() {
        return crtdDate;
    }

    public void setCrtdDate(String crtdDate) {
        this.crtdDate = crtdDate;
    }

    public String getCrtdTerminalId() {
        return crtdTerminalId;
    }

    public void setCrtdTerminalId(String crtdTerminalId) {
        this.crtdTerminalId = crtdTerminalId;
    }

    public String getDefTypeId() {
        return defTypeId;
    }

    public void setDefTypeId(String defTypeId) {
        this.defTypeId = defTypeId;
    }

    public String getDefTypeDescription() {
        return defTypeDescription;
    }

    public void setDefTypeDescription(String defTypeDescription) {
        this.defTypeDescription = defTypeDescription;
    }

    public String getDetailId() {
        return detailId;
    }

    public void setDetailId(String detailId) {
        this.detailId = detailId;
    }

    public String getDetailDescription() {
        return detailDescription;
    }

    public void setDetailDescription(String detailDescription) {
        this.detailDescription = detailDescription;
    }
    
    
}
