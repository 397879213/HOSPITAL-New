/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BO.Client;

/**
 *
 * @author admin
 */
public class POFEmployeeMapperBO {
    
    private String defId = "";
    private String defDescription = "";
    private String updatePofId = "";
    private String updateHmisId = "";
    private String hmisId = "";
    private String hmisDescription = "";
    private String pofId = "";
    private String pofDescription = "";
    private String actionId = "";
    private String active = "";
    private String crtdBy = "";
    private String crtdDate = "";
    private String crtdTerminalId = "";

    public String getHmisId() {
        return hmisId;
    }

    public void setHmisId(String hmisId) {
        this.hmisId = hmisId;
    }

    public String getHmisDescription() {
        return hmisDescription;
    }

    public void setHmisDescription(String hmisDescription) {
        this.hmisDescription = hmisDescription;
    }

    public String getPofId() {
        return pofId;
    }

    public void setPofId(String pofId) {
        this.pofId = pofId;
    }

    public String getPofDescription() {
        return pofDescription;
    }

    public void setPofDescription(String pofDescription) {
        this.pofDescription = pofDescription;
    }

    public String getActionId() {
        return actionId;
    }

    public void setActionId(String actionId) {
        this.actionId = actionId;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getCrtdBy() {
        return crtdBy;
    }

    public void setCrtdBy(String crtdBy) {
        this.crtdBy = crtdBy;
    }

    public String getCrtdDate() {
        return crtdDate;
    }

    public void setCrtdDate(String crtdDate) {
        this.crtdDate = crtdDate;
    }

    public String getCrtdTerminalId() {
        return crtdTerminalId;
    }

    public void setCrtdTerminalId(String crtdTerminalId) {
        this.crtdTerminalId = crtdTerminalId;
    }

    public String getDefId() {
        return defId;
    }

    public void setDefId(String defId) {
        this.defId = defId;
    }

    public String getDefDescription() {
        return defDescription;
    }

    public void setDefDescription(String defDescription) {
        this.defDescription = defDescription;
    }

    public String getUpdateHmisId() {
        return updateHmisId;
    }

    public void setUpdateHmisId(String updateHmisId) {
        this.updateHmisId = updateHmisId;
    }

    public String getUpdatePofId() {
        return updatePofId;
    }

    public void setUpdatePofId(String updatePofId) {
        this.updatePofId = updatePofId;
    }
}
